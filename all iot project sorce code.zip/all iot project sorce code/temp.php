<!DOCTYPE html>
<html>
<body>

<h1>Show a Date and Time Control</h1>

<form action="https://iot-projects-101.wuaze.com/temp2.php" methode ="get">
  <input type="text" name="a">
  <input type="submit">
</form>

</body>
</html>